﻿using Smod2;
using Smod2.API;
using Smod2.Attributes;
using Smod2.Config;
using Smod2.EventHandlers;
using Smod2.Events;
using Smod2.Lang;
using Smod2.Piping;
using System.Collections.Generic;
using System.IO;
using System;

namespace WaitingAndChilling
{
    [PluginDetails(
        author = "F4Fridey",
        name = "WaitingAndChilling",
        description = "Spawns people in within a confined area while waiting for players.",
        id = "f4fridey.waitingandchilling.plugin",
        configPrefix = "wac",
        langFile = "",
        version = "1.0",
        SmodMajor = 3,
        SmodMinor = 4,
        SmodRevision = 0
        )]

    public class WaitingAndChilling : Plugin
    {

        [ConfigOption("enabled")]
        public readonly bool enabled = true;

        [ConfigOption("coordinate_x")]
        public readonly float x = 53;

        [ConfigOption("coordinate_y")]
        public readonly float y = 1020;

        [ConfigOption("coordinate_z")]
        public readonly float z = -43;

        [ConfigOption("giveItems")]
        public readonly bool giveItems = false;

        [ConfigOption("role")]
        public readonly int role = 14;

        public override void OnDisable()
        {
            this.Info("WaitingAndChilling not loaded. Error: OnDisabled() triggered.");
        }

        public override void OnEnable()
        {
            if (enabled)
            {
                this.Info("WaitingAndChilling loaded succesfully. :)");
            } else
            {
                this.Info("WaitingAndChilling not loaded. Error: wac_enabled: false");
            }
        }

        public override void Register()
        {
            this.AddEventHandlers(new RoundEventHandler(this));
        }
    }
}
