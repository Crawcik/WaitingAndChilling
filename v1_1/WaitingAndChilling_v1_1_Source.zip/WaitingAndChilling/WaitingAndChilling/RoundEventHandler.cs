﻿using Smod2;
using Smod2.API;
using Smod2.EventHandlers;
using Smod2.Events;
using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace WaitingAndChilling
{
    class RoundEventHandler : IEventHandlerRoundStart, IEventHandlerRoundRestart, IEventHandlerPlayerJoin
    {
        private readonly WaitingAndChilling plugin;
        //private List<Player> playerlist;
        private bool roundstarted;
        private List<Player> playerList;
        private Role[] roles = { Role.SCP_173, Role.CLASSD, Role.SPECTATOR, Role.SCP_106, Role.NTF_SCIENTIST, Role.SCP_049, Role.SCIENTIST, Role.SCP_079, Role.CHAOS_INSURGENCY, Role.SCP_096, Role.SCP_049_2, Role.NTF_LIEUTENANT, Role.NTF_COMMANDER, Role.NTF_CADET, Role.TUTORIAL, Role.FACILITY_GUARD, Role.SCP_939_53, Role.SCP_939_89 };
        
        public RoundEventHandler(WaitingAndChilling plugin)
        {
            this.plugin = plugin;
            roundstarted = false;
        }

        public void spawnAndTP(Player player)
        {
            if (plugin.role >= 0 && plugin.role <= 17)
            {
                player.ChangeRole(roles[plugin.role], true, false);
                if (plugin.role != 14)
                {
                    player.SetGodmode(true);
                }
                player.Teleport(new Vector(plugin.x, plugin.y, plugin.z));
                if (plugin.giveItems)
                {
                    player.GiveItem(ItemType.USP);
                    player.SetAmmo(AmmoType.DROPPED_9, 100);
                    player.GiveItem(ItemType.E11_STANDARD_RIFLE);
                    player.SetAmmo(AmmoType.DROPPED_7, 100);
                    player.GiveItem(ItemType.LOGICER);
                    player.SetAmmo(AmmoType.DROPPED_5, 100);
                }
            }
            else
            {
                plugin.Info(plugin.role.ToString() + "is not a valid class.");
            }
            
        }

        public void OnRoundRestart(RoundRestartEvent ev)
        {
            roundstarted = false;
        }

        public void OnRoundStart(RoundStartEvent ev)
        {
            roundstarted = true;
            if (plugin.role != 14)
            {
                playerList = plugin.Server.GetPlayers();
                for (int i = 0; i < playerList.Count; i++)
                {
                    if (playerList[i].TeamRole.Role != Role.TUTORIAL)
                        playerList[i].SetGodmode(false);
                }
            }
            
        }

        public void OnPlayerJoin(PlayerJoinEvent ev)
        {
            if (!roundstarted)
            {
                spawnAndTP(ev.Player);
            }
        }
    }
}
