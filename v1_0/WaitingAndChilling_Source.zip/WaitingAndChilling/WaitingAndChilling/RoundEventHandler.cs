﻿using Smod2;
using Smod2.API;
using Smod2.EventHandlers;
using Smod2.Events;
using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace WaitingAndChilling
{
    class RoundEventHandler : IEventHandlerRoundStart, IEventHandlerRoundRestart, IEventHandlerPlayerJoin
    {
        private readonly WaitingAndChilling plugin;
        //private List<Player> playerlist;
        private bool roundstarted;
        
        public RoundEventHandler(WaitingAndChilling plugin)
        {
            this.plugin = plugin;
            roundstarted = false;
        }

        public void spawnAndTP(Player player)
        {
            player.ChangeRole(Role.TUTORIAL, true, false);
            player.Teleport(new Vector(plugin.x, plugin.y, plugin.z));
            if (plugin.giveItems)
            {
                player.GiveItem(ItemType.USP);
                player.SetAmmo(AmmoType.DROPPED_9, 100);
                player.GiveItem(ItemType.E11_STANDARD_RIFLE);
                player.SetAmmo(AmmoType.DROPPED_7, 100);
                player.GiveItem(ItemType.LOGICER);
                player.SetAmmo(AmmoType.DROPPED_5, 100);
            }
        }

        public void OnRoundRestart(RoundRestartEvent ev)
        {
            roundstarted = false;
        }

        public void OnRoundStart(RoundStartEvent ev)
        {
            roundstarted = true;
        }

        public void OnPlayerJoin(PlayerJoinEvent ev)
        {
            if (!roundstarted)
            {
                spawnAndTP(ev.Player);
            }
        }
    }
}
