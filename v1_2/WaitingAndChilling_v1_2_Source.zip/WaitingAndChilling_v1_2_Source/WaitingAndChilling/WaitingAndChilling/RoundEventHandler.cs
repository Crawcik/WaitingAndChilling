﻿using Smod2;
using Smod2.API;
using Smod2.EventHandlers;
using Smod2.Events;
using System.Collections.Generic;

namespace WaitingAndChilling
{
    class RoundEventHandler : IEventHandlerPlayerJoin
    {
        private readonly WaitingAndChilling plugin;
        private List<Player> playerList;
        public RoundEventHandler(WaitingAndChilling plugin)
        {
            this.plugin = plugin;
        }

        public void spawnAndTP(Player player)
        {
            if (plugin.role >= 0 && plugin.role <= 17)
            {
				player.ChangeRole((Role)plugin.role, true, false);
				if (plugin.role != 14)
                {
                    player.SetGodmode(true);
				}
			}
			else
			{
				plugin.Info(plugin.role.ToString() + " is not a valid class. Spawning " + player.Name + " as TUTORIAL instead.");
				player.ChangeRole(Role.TUTORIAL, true, false);
			}
			player.Teleport(new Vector(plugin.x, plugin.y, plugin.z));
            if (plugin.giveItems)
            {
                player.GiveItem(ItemType.USP);
                player.SetAmmo(AmmoType.DROPPED_9, 100);
                player.GiveItem(ItemType.E11_STANDARD_RIFLE);
                player.SetAmmo(AmmoType.DROPPED_7, 100);
                player.GiveItem(ItemType.LOGICER);
                player.SetAmmo(AmmoType.DROPPED_5, 100);
            }
        }

        public void OnRoundStart(RoundStartEvent ev)
		{
			if (!plugin.enabled) return;
			if (plugin.role != 14)
            {
                playerList = plugin.Server.GetPlayers();
                for (int i = 0; i < playerList.Count; i++)
                {
                    if (playerList[i].TeamRole.Role != Role.TUTORIAL)
                        playerList[i].SetGodmode(false);
                }
            }
        }

        public void OnPlayerJoin(PlayerJoinEvent ev)
        {
			if (!plugin.enabled) return;
            if (PluginManager.Manager.Server.Round.Duration == 0)
            {
                spawnAndTP(ev.Player);
            }
        }
    }
}
